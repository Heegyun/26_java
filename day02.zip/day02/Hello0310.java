package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
