
public class CartItem {

	
	//private String[] itemBook = new String[7];
	private Book itemBook;
	private String bookID;
	private int quantity;
	private int totalPrice;
	
	public CartItem(Book booklist) {
		this.itemBook = booklist;
		this.bookID = booklist.bookId;
		this.quantity = 1;
		updateTotalPrice();
	}
	/*public CartItem(String[] book) {
		this.itemBook = book;
		this.bookID = book[0];
		this.quantity = 1;
		updateTotalPrice();
	}
	
	public String[] getItemBook() {
		return itemBook;
	}
	public void setItemBook(String[] itemBook) {
		this.itemBook = itemBook;
	}
	*/
	public String getBookID() {
		return bookID;
	}
	public Book getItemBook() {
		return itemBook;
	}
	public void setItemBook(Book itemBook) {
		this.itemBook = itemBook;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public void updateTotalPrice() {
		//totalPrice = Integer.parseInt(this.itemBook[2])* this.quantity;
		totalPrice = this.itemBook.getUnitPrice()*this.quantity;
	}
}
